/* Create databse 
*/
CREATE DATABASE [ProjectDB]
GO

/* Open database 
*/
USE ProjectDB; 
GO

CREATE TABLE [dbo].[Customer] (
    [CustId]		INT      IDENTITY (1, 1)	NOT NULL,
    [CustName]		VARCHAR (30)				NOT NULL,
	[CustPassword]	VARCHAR (30)				NOT NULL,

	CONSTRAINT [PK_Customer_CustId] PRIMARY KEY ([CustId])
);

CREATE TABLE [dbo].[Account] (
	[AccountId] INT		IDENTITY (1, 1)	 NOT NULL,
    [CustId]    INT						 NOT NULL,

	CONSTRAINT [PK_Account_AccountId] PRIMARY KEY ([AccountId]),
	CONSTRAINT [FK_Account_CustId] FOREIGN KEY ([CustId]) REFERENCES [dbo].[Customer] ([CustId])
);

CREATE TABLE [dbo].[Chequing] (
	[ChequingId] INT		IDENTITY (1, 1)	 NOT NULL,
    [AccountId]  INT						 NOT NULL,
	[ChBalance]  FLOAT						 NOT NULL,

	CONSTRAINT [PK_Chequing_ChequingId] PRIMARY KEY ([ChequingId]),
	CONSTRAINT [FK_Chequing_AccountId] FOREIGN KEY ([AccountId]) REFERENCES [dbo].[Account] ([AccountId])
);

CREATE TABLE [dbo].[Credit] (
	[CreditId]	INT		IDENTITY (1, 1)	 NOT NULL,
    [AccountId] INT						 NOT NULL,
	[CrBalance] FLOAT					 NOT NULL,

	CONSTRAINT [PK_Credit_CreditId] PRIMARY KEY ([CreditId]),
	CONSTRAINT [FK_Credit_AccountId] FOREIGN KEY ([AccountId]) REFERENCES [dbo].[Account] ([AccountId])
);



INSERT INTO dbo.Customer (CustName, CustPassword)
VALUES ('Max','123');

INSERT INTO dbo.Customer (CustName, CustPassword)
VALUES ('Luke','123');

INSERT INTO dbo.Customer (CustName, CustPassword)
VALUES ('Kevin','123');

INSERT INTO dbo.Account (CustId)
VALUES (1);

INSERT INTO dbo.Account (CustId)
VALUES (2);

INSERT INTO dbo.Account (CustId)
VALUES (3);

INSERT INTO dbo.Chequing (AccountId, ChBalance)
VALUES (1, 30000);

INSERT INTO dbo.Credit (AccountId, CrBalance)
VALUES (1, 3000);

INSERT INTO dbo.Chequing (AccountId, ChBalance)
VALUES (2, 20000);

INSERT INTO dbo.Credit (AccountId, CrBalance)
VALUES (2, 2200);

--DROP TABLE dbo.Credit;
--DROP TABLE dbo.Chequing;
--DROP TABLE dbo.Account;
--DROP TABLE dbo.Customer;