﻿//Author: Luke Dam
//Default Menu page that allows a user to sign in
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GroupProject
{
    public partial class Default : System.Web.UI.Page
    {
        string connectionString = null;
        SqlConnection cnn;
        SqlCommand command;

        /// <summary>  
        ///  Page load method that estabishes data connection
        /// </summary> 
        protected void Page_Load(object sender, EventArgs e)
        {
            connectionString = "Data Source=DESKTOP-8HLQGJP;Initial Catalog = ProjectDB; " +
                "Integrated Security = SSPI; Persist Security Info = false";

            cnn = new SqlConnection(connectionString);
        }

        /// <summary>  
        ///  On clicking sign in button, authenticates and validates user
        /// </summary> 
        protected void SignInBtn_Click(object sender, EventArgs e)
        {
            try
            {
                cnn.Open();
                // Select required to match username with existing database
                command = new SqlCommand("SELECT * FROM dbo.Customer " +
                    "WHERE CustName = @CustName AND CustPassword = @Password", cnn);

                command.Parameters.AddWithValue("@CustName", this.UsernameText.Text);
                command.Parameters.AddWithValue("@Password", this.PasswordText.Text);

                int r = command.ExecuteNonQuery();

                SqlDataReader reader = command.ExecuteReader();

                // Authentication check done with the data reader
                while (reader.Read())
                {
                    if (this.UsernameText.Text == reader["CustName"].ToString() &&
                        this.PasswordText.Text == reader["CustPassword"].ToString())
                    {
                        Session["Username"] = UsernameText.Text;
                        Session["CustId"] = reader["CustId"].ToString();
                        Response.Redirect("Menu.aspx", false);
                    }
                    else
                    {
                        ErrorLbl.Text = "Incorrect Username or Password.";
                    }
                }
                cnn.Close();
                PasswordText.Text = String.Empty; // Empties out the password box for ease of use
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error in SQL! " + ex.Message);
                Console.ReadKey();

            }
            finally
            {
                if (cnn.State == ConnectionState.Open)

                {
                    cnn.Close();
                }
            }

            
        }

    }
}