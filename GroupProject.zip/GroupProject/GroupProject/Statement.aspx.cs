﻿//Author: Kevin Kim
//Viewing statement page for the user
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GroupProject.ServiceReference1;

namespace GroupProject
{

    
    public partial class Statement : System.Web.UI.Page
    {
        string ID = null;
        string connectionString = null;
        SqlConnection cnn;
        SqlCommand command;

        /// <summary>  
        ///  Page load method that estabishes data connection and sets the appropriate balance to their labels
        /// </summary> 
        protected void Page_Load(object sender, EventArgs e)
        {
            string [] storeArray;  // instantiate an array collection object to store both balances
            string [] amt = new string [2];
            ID = Session["CustId"].ToString();
            connectionString = "Data Source=DESKTOP-8HLQGJP;Initial Catalog = ProjectDB; " +
                "Integrated Security = SSPI; Persist Security Info = false";

            cnn = new SqlConnection(connectionString);

            try
            {
                cnn.Open();
                command = new SqlCommand("SELECT * FROM dbo.Account, dbo.Chequing, dbo.Credit " +
                    "WHERE dbo.Account.AccountId = dbo.Chequing.AccountId " +
                    "AND dbo.Account.AccountId = dbo.Credit.AccountId " +
                    "AND dbo.Credit.AccountId = dbo.Chequing.AccountId " +
                    "AND dbo.Account.CustId = @CustId", cnn);


                command.Parameters.AddWithValue("@CustId", ID);

                int r = command.ExecuteNonQuery();
                int r1 = command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();
                
                while (reader.Read())
                {
                     amt[0] = reader["ChBalance"].ToString();
                     amt[1] = reader["CrBalance"].ToString();
                }

                ChequeAmt.Text = amt[0];
                CreditAmt.Text = amt[1];

                cnn.Close();
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error in SQL! " + ex.Message);
                Console.ReadKey();

            }
            finally
            {
                if (cnn.State == ConnectionState.Open)

                {
                    cnn.Close();
                }
            }
        }
    }
}