﻿//Author: Luke Dam
//Default Deposit page that allows a user to add funds to chequing balance
using GroupProject.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GroupProject
{
    public partial class Deposit : System.Web.UI.Page
    {
        string ID = null;
        string connectionString = null;
        SqlConnection cnn;
        SqlCommand command;
        SqlCommand command1; // need a separate connection to retrieve 2 data at once
        ServiceReference1.Service1Client client = new ServiceReference1.Service1Client(); // globally define the service client
        Customer cust = new Customer();
        Chequing ch = new Chequing();

        /// <summary>  
        ///  Page load method that estabishes data connection
        /// </summary> 
        protected void Page_Load(object sender, EventArgs e)
        {
            ID = Session["CustId"].ToString();
            connectionString = "Data Source=DESKTOP-8HLQGJP;Initial Catalog = ProjectDB; " +
                "Integrated Security = SSPI; Persist Security Info = false";

            cnn = new SqlConnection(connectionString);
        }

        /// <summary>  
        ///  On clicking deposit button, deposits the input amount to the chequing balance
        /// </summary> 
        protected void DepositBtn_Click(object sender, EventArgs e)
        {
            Label1.Text = string.Empty;

            Page.Validate("Deposit.aspx"); // to validate before updating the records
            if (!Page.IsValid) { }

            else if (double.Parse(DepositTxt.Text) < 0)
            {
                Label1.Text = "Must be greater than 0. Please Try Again.";
            }

            else
            {
                cust.payAmt = double.Parse(DepositTxt.Text);
                ch.ChBalance = double.Parse(DepositTxt.Text);

                try
                {
                    cnn.Open();
                    // must grab the chequing balance to update the customer
                    command1 = new SqlCommand("SELECT ChBalance " +
                       "FROM dbo.Chequing, dbo.Account, dbo.Customer " +
                       "WHERE (dbo.Chequing.AccountId = dbo.Account.AccountId " +
                       "AND dbo.Account.CustId = dbo.Customer.CustId) " +
                       "AND dbo.Customer.CustId = @CustId2", cnn);

                    command1.Parameters.AddWithValue("@CustId2", ID);

                    int r1 = command1.ExecuteNonQuery();

                    SqlDataReader reader = command1.ExecuteReader();

                    while (reader.Read())
                    {
                        ch.ChBalance = double.Parse(reader["ChBalance"].ToString());
                    }

                    cnn.Close();

                    cnn.Open();
                    command = new SqlCommand("UPDATE dbo.Chequing " +
                        "SET dbo.Chequing.ChBalance = @ChBalance " +
                        "WHERE dbo.Chequing.AccountId = (SELECT " +
                        "dbo.Account.AccountId FROM dbo.Account WHERE " +
                        "dbo.Account.CustId = @CustId)", cnn);

                    command.Parameters.AddWithValue("@CustId", ID);
                    command.Parameters.AddWithValue("@ChBalance", client.addChequing(ch, cust).ToString());
                    int r = command.ExecuteNonQuery();

                    cnn.Close();
                    // redirect to menu done after successful transaction
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                        "alert('Transaction Successful!');window.location ='Menu.aspx';",
                        true);
                }

                catch (SqlException ex)
                {
                    Console.WriteLine("Error in SQL! " + ex.Message);
                    Console.ReadKey();

                }
                finally
                {
                    if (cnn.State == ConnectionState.Open)

                    {
                        cnn.Close();
                    }
                }
            }
        }

    }
}