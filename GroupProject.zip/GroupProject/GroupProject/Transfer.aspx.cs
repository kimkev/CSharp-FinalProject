﻿//Author: Luke Dam
//Transfer page for the user
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GroupProject.ServiceReference1;

namespace GroupProject
{
    public partial class Transfer : System.Web.UI.Page
    {
        string ID = null;
        string StringA { get; set; }

        string connectionString = null;
        SqlConnection cnn;
        // 3 commands needed for updating the database, set up globally
        SqlCommand command;
        SqlCommand command1;
        SqlCommand command2;
        ServiceReference1.Service1Client client = new ServiceReference1.Service1Client(); //client is set up globally
        Customer cust = new Customer();
        Chequing ch = new Chequing();
        Credit cr = new Credit();

        /// <summary>  
        ///  Page load method that estabishes data connection and sets the appropriate balance to their labels
        /// </summary>
        protected void Page_Load(object sender, EventArgs e)
        {
            ID = Session["CustId"].ToString();
            connectionString = "Data Source=DESKTOP-8HLQGJP;Initial Catalog = ProjectDB; " +
                "Integrated Security = SSPI; Persist Security Info = false";

            cnn = new SqlConnection(connectionString);

            DataTable users = new DataTable();
            try
            {
                cnn.Open();
                command = new SqlCommand("SELECT * FROM dbo.Account, dbo.Chequing, dbo.Credit " +
                    "WHERE dbo.Account.AccountId = dbo.Chequing.AccountId " +
                    "AND dbo.Account.AccountId = dbo.Credit.AccountId " +
                    "AND dbo.Credit.AccountId = dbo.Chequing.AccountId " +
                    "AND dbo.Account.CustId = @CustId", cnn);

                command.Parameters.AddWithValue("@CustId", ID);

                int r = command.ExecuteNonQuery();
                int r1 = command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ChequeAmt.Text = reader["ChBalance"].ToString();
                }
                cnn.Close();

                cnn.Open();
                
                command1 = new SqlCommand("SELECT CustId, CustName FROM dbo.Customer ", cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command1);
                adapter.Fill(users);
                if (!Page.IsPostBack) {
                    DdlUsers.DataSource = users;
                    DdlUsers.DataTextField = "CustName";
                    DdlUsers.DataValueField = "CustId";
                    DdlUsers.DataBind();

                    DdlUsers.Items.Insert(0, new ListItem("Select User", "0"));
                }

                cnn.Close();
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error in SQL! " + ex.Message);
                Console.ReadKey();

            }
            finally
            {
                if (cnn.State == ConnectionState.Open)

                {
                    cnn.Close();
                }
            }
        }

        /// <summary>  
        ///  drop down menu's selected value stored in a session
        /// </summary>
        protected void SelectedIndexChanged(object sender, EventArgs e)
        {
            
            StringA = DdlUsers.SelectedValue;
            Session["test"] = StringA;
        }

        /// <summary>  
        /// On transfer button click validates and update chequing on two users reflecting amount transferred
        /// </summary>
        protected void TransferBtn_Click(object sender, EventArgs e)
        {
            Label1.Text = string.Empty;
            Label2.Text = string.Empty;

            // Page must pass validation before updating the database
            Page.Validate("Transfer.aspx");
            if (!Page.IsValid) { }

            else if (double.Parse(ChequeAmt.Text) < double.Parse(AmountTxt.Text))
            {
                Label1.Text = "Not enough funds Available. Please Try Again.";
            }

            else if (double.Parse(AmountTxt.Text) < 0)
            {
                Label2.Text = "Must be greater than 0. Please Try Again.";
            }

            else {
                int storeId = int.Parse(Session["test"].ToString());
                cust.payAmt = double.Parse(AmountTxt.Text.ToString());

                try
                {
                    cnn.Open();
                    // selecting the 2nd customer as it is required for updating their balance
                    command1 = new SqlCommand("SELECT ChBalance " +
                       "FROM dbo.Chequing, dbo.Account, dbo.Customer " +
                       "WHERE (dbo.Chequing.AccountId = dbo.Account.AccountId " +
                       "AND dbo.Account.CustId = dbo.Customer.CustId) " +
                       "AND dbo.Customer.CustId = @CustId2", cnn);

                    command1.Parameters.AddWithValue("@CustId2", storeId);

                    int r1 = command1.ExecuteNonQuery();

                    SqlDataReader reader = command1.ExecuteReader();

                    while (reader.Read())
                    {
                        ch.ChBalance = double.Parse(reader["ChBalance"].ToString());

                    }

                    cnn.Close();

                    cnn.Open();
                    command = new SqlCommand("UPDATE dbo.Chequing " +
                        "SET dbo.Chequing.ChBalance = @ChBalance " +
                        "FROM dbo.Chequing, dbo.Account, dbo.Customer " +
                        "WHERE (dbo.Chequing.AccountId = dbo.Account.AccountId " +
                        "AND dbo.Account.CustId = dbo.Customer.CustId) " +
                        "AND dbo.Customer.CustId = @CustId", cnn);

                    command.Parameters.AddWithValue("@CustId", storeId);
                    command.Parameters.AddWithValue("@ChBalance", client.addChequing(ch,cust));

                    int r = command.ExecuteNonQuery();

                    cnn.Close();

                    cnn.Open();

                    ch.ChBalance = double.Parse(ChequeAmt.Text);

                    command2 = new SqlCommand("UPDATE dbo.Chequing " +
                        "SET dbo.Chequing.ChBalance = @ChBalance " +
                        "FROM dbo.Chequing, dbo.Account, dbo.Customer " +
                        "WHERE (dbo.Chequing.AccountId = dbo.Account.AccountId " +
                        "AND dbo.Account.CustId = dbo.Customer.CustId) " +
                        "AND dbo.Customer.CustId = @CustId", cnn);

                    command2.Parameters.AddWithValue("@CustId", ID);
                    command2.Parameters.AddWithValue("@ChBalance", client.minusChequing(ch, cust));

                    int r2 = command2.ExecuteNonQuery();

                    cnn.Close();

                    // on transaction success loads back to the menu page
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                        "alert('Transaction Successful!');window.location ='Menu.aspx';",
                        true);
                }

                catch (SqlException ex)
                {
                    Console.WriteLine("Error in SQL! " + ex.Message);
                    Console.ReadKey();

                }
                finally
                {
                    if (cnn.State == ConnectionState.Open)

                    {
                        cnn.Close();
                    }
                }
            }
        }

    }
}