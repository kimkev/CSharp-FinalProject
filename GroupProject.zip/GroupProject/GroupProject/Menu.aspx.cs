﻿//Author: Kevin Kim
//global page defining the script manager & jquery
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GroupProject
{
    public partial class Menu : System.Web.UI.Page
    {
        /// <summary>  
        ///  On page load, defines the welcome text to the appropriate user using the session
        /// </summary> 
        protected void Page_Load(object sender, EventArgs e)
        {
            UserTxt.Text = Session["Username"].ToString();
        }

        /// <summary>  
        ///  On clicking transfer button, loads the transfer page
        /// </summary> 
        protected void TransferBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Transfer.aspx");
        }

        /// <summary>  
        ///  On clicking pay button, loads the pay page
        /// </summary> 
        protected void PayBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Pay.aspx");
        }

        /// <summary>  
        ///  On clicking statement button, loads the statement page
        /// </summary> 
        protected void StatementBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Statement.aspx");
        }

        /// <summary>  
        ///  On clicking deposit button, loads the deposit page
        /// </summary> 
        protected void DepositBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Deposit.aspx");
        }

        /// <summary>  
        ///  On clicking log out button, loads the sign in page
        /// </summary> 
        protected void LogoutBtn_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Default.aspx");
        }
    }
}