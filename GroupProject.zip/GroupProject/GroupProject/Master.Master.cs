﻿//Author: Luke Dam
//Master page defining the home button
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GroupProject
{
    public partial class Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        /// <summary>  
        ///  On clicking home, the user can redirect back to the menu page
        /// </summary> 
        protected void Home_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu.aspx");
        }
    }
}