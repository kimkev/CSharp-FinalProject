﻿//Author: Luke Dam
//Pay page for the user
using GroupProject.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GroupProject
{
    public partial class Pay : System.Web.UI.Page
    {
        string connectionString = null;
        SqlConnection cnn;
        SqlCommand command;
        SqlCommand command1;
        ServiceReference1.Service1Client client = new ServiceReference1.Service1Client(); // define the customer globally
        Customer cust = new Customer();
        Chequing ch = new Chequing();
        Credit cr = new Credit();

        /// <summary>  
        ///  Page load method that estabishes data connection and sets the appropriate balance to their labels
        /// </summary> 
        protected void Page_Load(object sender, EventArgs e)
        {
            ID = Session["CustId"].ToString();
            connectionString = "Data Source=DESKTOP-8HLQGJP;Initial Catalog = ProjectDB; " +
                "Integrated Security = SSPI; Persist Security Info = false";

            cnn = new SqlConnection(connectionString);
            
            try
            {
                cnn.Open();
                command = new SqlCommand("SELECT * FROM dbo.Account, dbo.Chequing, dbo.Credit " +
                    "WHERE dbo.Account.AccountId = dbo.Chequing.AccountId " +
                    "AND dbo.Account.AccountId = dbo.Credit.AccountId " +
                    "AND dbo.Credit.AccountId = dbo.Chequing.AccountId " +
                    "AND dbo.Account.CustId = @CustId", cnn);


                command.Parameters.AddWithValue("@CustId", ID);

                int r = command.ExecuteNonQuery();
                int r1 = command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ChequeAmt1.Text = reader["ChBalance"].ToString(); //text must be defined while data exists
                    CreditAmt.Text = reader["CrBalance"].ToString();
                }
                cnn.Close();
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error in SQL! " + ex.Message);
                Console.ReadKey();

            }
            finally
            {
                if (cnn.State == ConnectionState.Open)

                {
                    cnn.Close();
                }
            }
        }

        /// <summary>  
        ///  On clicking pay button updates database after using the service to calculate chequing balance
        /// </summary> 
        protected void PayBtn_Click(object sender, EventArgs e)
        {

            Label1.Text = string.Empty;
            Label2.Text = string.Empty;
            Label3.Text = string.Empty;

            Page.Validate("Pay.aspx"); //validate's the page before submission
            if (!Page.IsValid) { }

            else if (double.Parse(ChequeAmt1.Text) < double.Parse(PayTxt.Text))
            {
                Label1.Text = "Not enough funds Available. Please Try Again.";
            }

            else if (double.Parse(CreditAmt.Text) < double.Parse(PayTxt.Text))
            {
                Label2.Text = "Cannot be greater than Credit Amount. Please Try Again.";
            }

            else if (double.Parse(PayTxt.Text) < 0)
            {
                Label3.Text = "Must be greater than 0. Please Try Again.";
            }

            else
            {
                //update customer information
                cust.payAmt = double.Parse(PayTxt.Text);
                ch.ChBalance = double.Parse(ChequeAmt1.Text);
                cr.CrBalance = double.Parse(CreditAmt.Text);

                try
                {
                    cnn.Open();
                    //update the chequing balance after updating the customer information
                    command = new SqlCommand("UPDATE dbo.Chequing " +
                        "SET dbo.Chequing.ChBalance = @ChBalance " +
                        "WHERE dbo.Chequing.AccountId = (SELECT " +
                        "dbo.Account.AccountId FROM dbo.Account WHERE " +
                        "dbo.Account.CustId = @CustId)", cnn);

                    command.Parameters.AddWithValue("@CustId", ID);
                    command.Parameters.AddWithValue("@ChBalance", client.minusChequing(ch, cust).ToString());
                    int r = command.ExecuteNonQuery();

                    cnn.Close();

                    cnn.Open();
                    //update the credit balance after updating the customer information
                    command1 = new SqlCommand("UPDATE dbo.Credit " +
                        "SET dbo.Credit.CrBalance = @CrBalance " +
                        "WHERE dbo.Credit.AccountId = (SELECT " +
                        "dbo.Account.AccountId FROM dbo.Account WHERE " +
                        "dbo.Account.CustId = @CustId)", cnn);


                    command1.Parameters.AddWithValue("@CustId", ID);
                    command1.Parameters.AddWithValue("@CrBalance", client.totalCredit(cr, cust).ToString());
                    int r1 = command1.ExecuteNonQuery();

                    cnn.Close();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                        "alert('Transaction Successful!');window.location ='Menu.aspx';", // load menu page after successful transaction
                        true);
                }

                catch (SqlException ex)
                {
                    Console.WriteLine("Error in SQL! " + ex.Message);
                    Console.ReadKey();

                }
                finally
                {
                    if (cnn.State == ConnectionState.Open)

                    {
                        cnn.Close();
                    }
                }
            }
        }
    }
}