﻿//Author: Luke Dam
//Service interface that lays out all the necessary contracts for the application
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CalculatorService
{
    [ServiceContract]
    public interface IService1
    {
        /// <summary>  
        ///  This method retrieves the customer's statement
        /// </summary>  
        [OperationContract]
        string getStatement(Customer customer);

        /// <summary>  
        ///  This method calculates the total of chequing and credit balance
        /// </summary>  
        [OperationContract]
        double total(Chequing ch, Credit cr);

        /// <summary>  
        ///  This method calculates the credit after a transaction
        /// </summary>  
        [OperationContract]
        double totalCredit(Credit cr, Customer customer);

        /// <summary>  
        ///  This method calculates the chequing after a transaction
        /// </summary>  
        [OperationContract]
        double minusChequing(Chequing ch, Customer customer);

        /// <summary>  
        ///  This method adds funds to the chequing balance
        /// </summary>  
        [OperationContract]
        double addChequing(Chequing ch, Customer customer);

    }


    [DataContract]
    public class Customer
    {
        /// <summary>  
        ///  This field defines the customer's ID
        /// </summary>  
        [DataMember]
        public int CustId
        {
            get; set;
        }

        /// <summary>  
        ///  This field defines the customer's user name
        /// </summary> 
        [DataMember]
        public string CustUsername
        {
            get; set;
        }

        /// <summary>  
        ///  This field defines the customer's password
        /// </summary> 
        [DataMember]
        public string CustPassword
        {
            get; set;
        }

        /// <summary>  
        ///  This field defines the customer's amount to be deducted
        /// </summary> 
        [DataMember]
        public double payAmt
        {
            get; set;
        }
    }

    public class Chequing {

        /// <summary>  
        ///  This field defines the customer's chequing balance
        /// </summary> 
        [DataMember]
        public double ChBalance
        {
            get; set;
        }
    }

    public class Credit {

        /// <summary>  
        ///  This field defines the customer's credit balance
        /// </summary> 
        [DataMember]
        public double CrBalance
        {
            get; set;
        }
    }
}
