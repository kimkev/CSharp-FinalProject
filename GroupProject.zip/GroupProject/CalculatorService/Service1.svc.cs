﻿//Author: Luke Dam
//Service class that defines all the services for the application
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CalculatorService
{
    public class Service1 : IService1
    {
        /// <summary>  
        ///  This method retrieves the customer's statement
        /// </summary> 
        public string getStatement(Customer customer)
        {
            return customer.CustPassword;
        }

        /// <summary>  
        ///  This method calculates the total of chequing and credit balance
        /// </summary>  
        public double total(Chequing ch, Credit cr)
        {

            return ch.ChBalance + cr.CrBalance;
        }

        /// <summary>  
        ///  This method calculates the credit after a transaction
        /// </summary>  
        public double totalCredit(Credit cr, Customer customer)
        {
            cr.CrBalance = cr.CrBalance - customer.payAmt;

            return cr.CrBalance;
        }

        /// <summary>  
        ///  This method calculates the chequing after a transaction
        /// </summary>  
        public double minusChequing(Chequing ch, Customer customer)
        {
            ch.ChBalance = ch.ChBalance - customer.payAmt;
            return ch.ChBalance;
        }

        /// <summary>  
        ///  This method adds funds to the chequing balance
        /// </summary> 
        public double addChequing(Chequing ch, Customer customer)
        {
            ch.ChBalance = ch.ChBalance + customer.payAmt;
            return ch.ChBalance;
        }
    }
}
